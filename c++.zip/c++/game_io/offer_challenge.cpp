#include "offer_challenge.h"

offer_challenge::offer_challenge() {
    this->set_type("offer_challenge");
}
