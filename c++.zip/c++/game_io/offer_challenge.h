#pragma once

#include "json_response.h"

class offer_challenge : public move_response {
    public:
        offer_challenge();
};
